import IdeaLeaderboard from "./IdeaLeaderboard";

export default IdeaLeaderboard