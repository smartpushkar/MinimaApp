export const Create_Claim = "CreateClaim";
export const Role_Merchant = "Merchant";
export const Role_User = "User";
export const Role_Super_Admin = "SuperAdmin";
export const Not_Register = "Not Register";
export const Pending_Status = "Pending";
// export const Pending_Approval = "Pending Approval";
export const ActiveStatus = "Active";
export const Rejected = "Rejected";
export const BlackListedStatus = "BlackListed";
export const Approved = "Approved";

