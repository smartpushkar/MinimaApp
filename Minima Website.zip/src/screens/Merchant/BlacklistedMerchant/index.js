import BlacklistedMerchant from "./BlacklistedMerchant";

export default BlacklistedMerchant