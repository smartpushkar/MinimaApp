import React from 'react';

const NoAccess = () => {
  return (
    <div>
      <h1>Access Denied</h1>
      <p>You don't have permission to access this page.</p>
      {/* Add any additional content or styling as needed */}
    </div>
  );
};

export default NoAccess;
