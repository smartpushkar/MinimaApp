import React from "react";
import Header from "../Header";
import Footer from "../Footer";

const IdeaLeaderboard = () =>{
    return(
        <>
        <Header/>
        <Footer/>
        </>
    )
}
export default IdeaLeaderboard