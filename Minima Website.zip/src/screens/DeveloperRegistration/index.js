import DeveloperRegistration from "./DeveloperRegistration";

export default DeveloperRegistration