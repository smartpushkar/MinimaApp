import * as authActions from './authActions';
// import * as emailOtpAction from './EmailOtpAction';

const exportedObject = {
    ...authActions,
}

export default exportedObject;