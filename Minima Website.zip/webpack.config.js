// module.exports = {
//     // ... other configurations
//     module: {
//       rules: [
//         {
//           test: /\.jsx?$/,
//           use: ['babel-loader', 'source-map-loader'],
//           exclude: /node_modules/,
//           enforce: 'pre'
//         },
//         {
//           test: /\.tsx?$/,
//           use: ['babel-loader', 'ts-loader', 'source-map-loader'],
//           exclude: /node_modules/,
//           enforce: 'pre'
//         },
//         {
//           test: /\.js$/,
//           use: ['source-map-loader'],
//           exclude: [
//             /node_modules\/react-bootstrap-sweetalert\/src\/components\/Buttons\.tsx?/,
//             /node_modules\/react-bootstrap-sweetalert\/dist\/styles\/SweetAlertStyles\.js/
//           ],
//           enforce: 'pre'
//         },
//       ]
//     }
//   };
  