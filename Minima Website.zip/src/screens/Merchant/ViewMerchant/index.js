import ViewMerchant from "./ViewMerchant";

export default ViewMerchant